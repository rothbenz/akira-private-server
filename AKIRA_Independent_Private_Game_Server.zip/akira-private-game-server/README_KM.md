# AKIRA Independent Private Game Server (Test)

This is a real, runnable **independent lobby/admin backend**. It is NOT a ROS Legacy server, does not connect to ROS Legacy, and cannot change ROS Legacy account diamonds.

## Run it
Requires Node.js 20+ on a VPS or other Node.js host. An iPhone can open the admin website in Safari, but should not be treated as the production server host.

1. Upload/extract this folder on a Node.js host.
2. Set environment variable `ADMIN_PASSWORD` to a new strong password (do not use a password you use elsewhere).
3. Run `npm install`
4. Run `npm start`
5. Open `https://YOUR-HOST/` in Safari.

For local testing on a computer: `ADMIN_PASSWORD='choose-a-strong-password' npm start`, then open `http://localhost:3000`.

## Included
- Create and list independent test lobbies
- Join a lobby by ID with a player name
- Admin login
- Server-side test diamond balance: add, remove, set
- JSON persistence in `data.json`

## Production hardening before public use
Use HTTPS, a strong unique admin password, firewall/rate limits, persistent disk backups, and a proper database. This starter stores sessions in memory, so logging out/restarting clears sessions. It is a prototype backend, not a production game engine.
