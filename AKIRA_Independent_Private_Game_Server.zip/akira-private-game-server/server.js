const express = require("express");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const app = express();
app.use(express.json({ limit: "32kb" }));
app.use(express.static(path.join(__dirname, "public")));

const PORT = Number(process.env.PORT || 3000);
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD;
if (!ADMIN_PASSWORD) {
  console.error("Set ADMIN_PASSWORD before starting the server.");
  process.exit(1);
}
const DB_FILE = path.join(__dirname, "data.json");
const sessions = new Set();

function loadDb() {
  try { return JSON.parse(fs.readFileSync(DB_FILE, "utf8")); }
  catch { return { lobbies: [], diamonds: 100000, updatedAt: new Date().toISOString() }; }
}
let db = loadDb();
function saveDb() {
  db.updatedAt = new Date().toISOString();
  fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
}
function auth(req, res, next) {
  const token = (req.headers.authorization || "").replace(/^Bearer\s+/i, "");
  if (!token || !sessions.has(token)) return res.status(401).json({ error: "Admin login required" });
  next();
}
function cleanName(value) {
  return String(value || "Player").trim().slice(0, 24).replace(/[<>]/g, "");
}

app.get("/api/health", (_req, res) => res.json({
  ok: true, service: "AKIRA Independent Test Server",
  note: "Independent test backend; not connected to ROS Legacy."
}));

app.post("/api/login", (req, res) => {
  if (!req.body || req.body.password !== ADMIN_PASSWORD) return res.status(401).json({ error: "Wrong password" });
  const token = crypto.randomBytes(32).toString("hex");
  sessions.add(token);
  res.json({ token, role: "admin" });
});

app.get("/api/status", (_req, res) => res.json({
  diamonds: db.diamonds,
  lobbies: db.lobbies.map(({ id, name, owner, players, createdAt, status }) => ({ id, name, owner, players, createdAt, status })),
  updatedAt: db.updatedAt
}));

app.post("/api/lobbies", (req, res) => {
  const name = cleanName(req.body && req.body.name || "AKIRA Solo Room");
  const lobby = {
    id: crypto.randomBytes(4).toString("hex").toUpperCase(),
    name, owner: cleanName(req.body && req.body.owner || "Admin"),
    players: [], maxPlayers: 8, status: "open",
    createdAt: new Date().toISOString()
  };
  db.lobbies.unshift(lobby);
  saveDb();
  res.status(201).json({ lobby });
});

app.post("/api/lobbies/:id/join", (req, res) => {
  const lobby = db.lobbies.find(x => x.id === req.params.id.toUpperCase());
  if (!lobby || lobby.status !== "open") return res.status(404).json({ error: "Lobby not found or closed" });
  const player = cleanName(req.body && req.body.player);
  if (!lobby.players.includes(player)) {
    if (lobby.players.length >= lobby.maxPlayers) return res.status(409).json({ error: "Lobby is full" });
    lobby.players.push(player);
    saveDb();
  }
  res.json({ lobby });
});

app.post("/api/lobbies/:id/close", auth, (req, res) => {
  const lobby = db.lobbies.find(x => x.id === req.params.id.toUpperCase());
  if (!lobby) return res.status(404).json({ error: "Lobby not found" });
  lobby.status = "closed";
  saveDb();
  res.json({ lobby });
});

app.post("/api/admin/diamonds", auth, (req, res) => {
  const { action, amount } = req.body || {};
  if (!Number.isSafeInteger(amount) || amount < 0) return res.status(400).json({ error: "Amount must be a non-negative whole number" });
  if (action === "set") db.diamonds = amount;
  else if (action === "add") db.diamonds = Math.min(Number.MAX_SAFE_INTEGER, db.diamonds + amount);
  else if (action === "remove") db.diamonds = Math.max(0, db.diamonds - amount);
  else return res.status(400).json({ error: "Action must be add, remove, or set" });
  saveDb();
  res.json({ diamonds: db.diamonds });
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`AKIRA test server listening on port ${PORT}`);
});
